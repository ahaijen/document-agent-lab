{
  "toolId": "300000339747893",
  "$context": {
    "etag": "1"
  },
  "createdBy": "CURTIS.FEITTY",
  "toolCreatedDate": "2026-09-08",
  "toolCode": "AH001_EXPENSE_POLICY_TOOL",
  "name": "AH001 Expense Policy Tool",
  "description": "Tool containing the company's expense policy document.",
  "family": "COMMON",
  "product": "OTHER",
  "type": "DOCUMENT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "COMMON.OTHER",
  "specification": {
    "customFlag": false,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": []
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "restTool": [],
  "deepLinkTool": [],
  "retrievalDocuments": [
    {
      "documentId": "300000339747894",
      "description": "The official expense policy document for the company.",
      "documentCreatedDate": "2026-09-08",
      "documentPublishedDate": "2026-09-08",
      "name": "Company Expense Policy",
      "status": "PUBLISHED",
      "$context": {
        "etag": "2"
      },
      "$attachments": [
        {
          "id": "300000339747895",
          "category": "MISC",
          "updatedBy": "CURTIS.FEITTY",
          "timeUpdated": "Sep 08, 2026",
          "document": {
            "id": "300000339749553",
            "description": "DOES NOT EXIST AT ALL BV.pdf",
            "fileName": "DOES NOT EXIST AT ALL BV.pdf",
            "mediaType": "application/pdf",
            "size": "162553",
            "timeUpdated": "Sep 08, 2026"
          }
        }
      ]
    }
  ],
  "messageDeliveryOptions": []
}

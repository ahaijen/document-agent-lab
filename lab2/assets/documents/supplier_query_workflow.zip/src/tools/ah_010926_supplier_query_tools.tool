{
  "toolId": "300000339490585",
  "$context": {
    "etag": "1"
  },
  "createdBy": "CURTIS.FEITTY",
  "toolCreatedDate": "2026-09-01",
  "toolCode": "AH_010926_SUPPLIER_QUERY_TOOLS",
  "name": "AH-010926 Supplier Query Tools",
  "description": "Read-only supplier lookup business object that searches by supplier name or supplier number.",
  "family": "FIN",
  "product": "OTHER",
  "type": "BUSINESS_OBJECT",
  "status": "PUBLISHED",
  "seededFlag": false,
  "version": 1,
  "userInputRequiredFlag": false,
  "userInputMessage": "",
  "subType": "",
  "namespace": "FIN.OTHER",
  "specification": {
    "customFlag": true,
    "jsonSchemaName": "Tool.spec",
    "jsonSchemaVersion": "1",
    "businessObjectMetadata": {
      "functions": [
        "searchSuppliersByNameOrNumber",
        "getSupplierDetails"
      ]
    },
    "externalRestMetadata": {
      "endpoints": [],
      "instanceURL": "",
      "extensionId": "",
      "serviceConnectionId": "",
      "authInfo": {}
    },
    "mcpConfig": {
      "credentialId": "",
      "credentialType": "none",
      "instanceURL": "",
      "tools": [],
      "type": "sse"
    },
    "kmConnectorConfig": {
      "connectorReferenceKey": "",
      "externalDocId": "",
      "externalDocVersionId": "",
      "type": "",
      "filters": [],
      "tools": []
    },
    "ragDocumentMetadata": {
      "authorization": {},
      "content": {},
      "contentArray": []
    },
    "sourceObjectCode": "ORA_FIN_OTHER_AH_010926_SUP_BO",
    "uiInput": {
      "responseSpec": "",
      "uiPatternSpec": "",
      "uiPatternType": "",
      "userInputType": ""
    }
  },
  "restTool": [
    {
      "restToolId": "300000339490586",
      "toolCode": "AH_010926_SUPPLIER_QUERY_TOOLS",
      "toolId": "300000339490585",
      "payloadTemplate": "",
      "specification": "",
      "seededFlag": false,
      "supportedObject": {
        "supportedObjectId": "300000339672622",
        "objectCode": "ORA_FIN_OTHER_AH_010926_SUP_BO"
      },
      "$context": {
        "etag": "1"
      }
    }
  ],
  "deepLinkTool": [],
  "retrievalDocuments": [],
  "messageDeliveryOptions": []
}
